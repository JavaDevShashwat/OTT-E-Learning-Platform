const path = require("path");
const express = require("express");

const mongoSanitize = require("express-mongo-sanitize");
const xss = require("xss-clean");
const hpp = require("hpp");
const rateLimit = require("express-rate-limit");
const cookieParser = require("cookie-parser");
const AppError = require("./utils/appError");
const globalErrorHandler = require("./controllers/errorController");
const viewRouter = require("./routes/viewRoutes");
const categoryRouter = require("./routes/categoryRoutes");
const videoRouter = require("./routes/videoRoutes");
const userRouter = require("./routes/userRoutes");
const notesRouter = require("./routes/notesRoutes");
const upcomingEventsRouter = require("./routes/upcomingEventsRoutes");
const authController = require("./controllers/authController");

const app = express();

app.use(express.json());

app.use(
  express.urlencoded({
    extended: true,
  })
);
app.use(cookieParser());
app.use(mongoSanitize());
app.use(xss());
app.use(express.static('public'))

app.set("view engine", "ejs");
app.set("views", path.join(__dirname, "views"));


app.use("/api/v1/category", categoryRouter);
app.use("/api/v1/videos", videoRouter);
app.use("/api/v1/notes", notesRouter);
app.use("/api/v1/upcoming-events", upcomingEventsRouter);
app.use("/api/v1/user", userRouter);
app.use("/", viewRouter);

//VIEW ROUTER
app.get('/', (req , res , next)=>{
  res.render('login');
})

app.all("*", (req, res, next) => {
	next(new AppError(`Can't find ${req.originalUrl} on this Server`, 404));
});


app.use(globalErrorHandler);

module.exports = app;
