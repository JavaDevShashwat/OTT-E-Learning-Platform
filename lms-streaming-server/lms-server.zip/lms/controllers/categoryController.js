// const { query } = require("express");
const express = require("express");
const mongoose = require("mongoose");
const Category = require("../models/categoryModel.js");

exports.getAllCategory = async (req, res, next) => {
	try {
		const category = await Category.find();
		res.status(200).json({
			status: "success",
			result: category.length,
			data: category,
		});
	} catch (error) {
		console.log(error);
	}
};

exports.addNewCategory = async (req, res, next) => {
	try {
		const category = await Category.create(req.body);
		res.status(201).json({
			status: "success",
			data: {
				category,
			},
		});
	} catch (error) {
		console.log(error);
	}
};

exports.getOneCategory = async (req, res, next) => {
	try {
		const category = await Category.findById(req.params.id);
		res.status(200).json({
			status: "success",
			data: {
				category,
			},
		});
	} catch (error) {
		console.log(error);
	}
};

exports.updateCategory = async (req, res, next) => {
	try {
		const category = await Category.findByIdAndUpdate(req.params.id, req.body, {
			new: true,
			runValidators: true,
		});
		res.status(200).json({
			status: "success",
			data: {
				category,
			},
		});
	} catch (error) {
		console.log(error);
	}
};

exports.deleteCategory = async (req, res, next) => {
	try {
		const category = await Category.findByIdAndDelete(req.params.id);
		res.status(204).json({
			status: "success",
			data: "null",
		});
	} catch (error) {
		console.log(error);
	}
};
