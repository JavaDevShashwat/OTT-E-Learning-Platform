import natural from 'natural';

natural.PorterStemmer.attach();

function prepareVideoLecture(VideoLectureMetaData, VideoLectureKeywords) {
  console.log('Preparing VideoLecture ... \n');

  // Pre-processing VideoLecture for unified data structure
  // E.g. get overview property into same shape as studio property
  console.log('(1) Zipping VideoLecture');
  let VideoLecture_IN_LIST = zip(VideoLectureMetaData, VideoLectureKeywords);
  VideoLecture_IN_LIST = withTokenizedAndStemmed(VideoLecture_IN_LIST, 'overview');
  VideoLecture_IN_LIST = fromArrayToMap(VideoLecture_IN_LIST, 'overview');

  // Keep a map of VideoLecture for later reference
  let VideoLecture_BY_ID = VideoLecture_IN_LIST.reduce(byId, {});

  console.log('(2) Creating Dictionaries');
  // Preparing dictionaries for feature extraction
  let DICTIONARIES = prepareDictionaries(VideoLecture_IN_LIST);

  // Feature Extraction:
  // Map different types to numerical values (e.g. adult to 0 or 1)
  // Map dictionaries to partial feature vectors
  console.log('(3) Extracting Features');
  let X = VideoLecture_IN_LIST.map(toFeaturizedVideoLecture(DICTIONARIES));

  // Extract a couple of valuable coefficients
  // Can be used in a later stage (e.g. feature scaling)
  console.log('(4) Calculating Coefficients');
  let { means, ranges } = getCoefficients(X);

  // Synthesize Features:
  // Missing features (such as budget, release, revenue)
  // can be synthesized with the mean of the features
  console.log('(5) Synthesizing Features');
  X = synthesizeFeatures(X, means, [0, 1, 2, 3, 4, 5, 6]);

  // Feature Scaling:
  // Normalize features based on mean and range vectors
  console.log('(6) Scaling Features \n');
  X = scaleFeatures(X, means, ranges);

  return {
    VideoLecture_BY_ID,
    VideoLecture_IN_LIST,
    X,
  };
}

export function byId(VideoLectureById, lecture) {
  VideoLectureById[lecture.id] = lecture;
  return VideoLectureById;
}

export function prepareDictionaries(VideoLecture) {
  let genresDictionary = toDictionary(VideoLecture, 'year');
  let studioDictionary = toDictionary(VideoLecture, 'subject');
  let keywordsDictionary = toDictionary(VideoLecture, 'keywords');
  let overviewDictionary = toDictionary(VideoLecture, 'overview');

  // Customize the threshold to your own needs
  // Depending on threshold you get a different size of a feature vector for a lecture
  // The following case attempts to keep feature vector small for computational efficiency
  genresDictionary = filterByThreshold(genresDictionary, 1);
  studioDictionary = filterByThreshold(studioDictionary, 75);
  keywordsDictionary = filterByThreshold(keywordsDictionary, 150);
  overviewDictionary = filterByThreshold(overviewDictionary, 750);

  return {
    genresDictionary,
    studioDictionary,
    keywordsDictionary,
    overviewDictionary,
  };
}

export function scaleFeatures(X, means, ranges) {
  return X.map((row) => {
    return row.map((feature, key) => {
      return (feature - means[key]) / ranges[key];
    });
  });
};

export function synthesizeFeatures(X, means, featureIndexes) {
  return X.map((row) => {
    return row.map((feature, key) => {
      if (featureIndexes.includes(key) && feature === 'undefined') {
        return means[key];
      } else {
        return feature;
      }
    });
  });
}

export function getCoefficients(X) {
  const M = X.length;

  const initC = {
    sums: [],
    mins: [],
    maxs: [],
  };

  const helperC = X.reduce((result, row) => {
    if (row.includes('undefined')) {
      return result;
    }

    return {
      sums: row.map((feature, key) => {
        if (result.sums[key]) {
          return result.sums[key] + feature;
        } else {
          return feature;
        }
      }),
      mins: row.map((feature, key) => {
        if (result.mins[key] === 'undefined') {
          return result.mins[key];
        }

        if (result.mins[key] <= feature) {
          return result.mins[key];
        } else {
          return feature;
        }
      }),
      maxs: row.map((feature, key) => {
        if (result.maxs[key] === 'undefined') {
          return result.maxs[key];
        }

        if (result.maxs[key] >= feature) {
          return result.maxs[key];
        } else {
          return feature;
        }
      }),
    };
  }, initC);

  const means = helperC.sums.map(value => value / M);
  const ranges =  helperC.mins.map((value, key) => helperC.maxs[key] - value);

  return { ranges, means };
}

export function toFeaturizedVideoLecture(dictionaries) {
  return function toFeatureVector(lecture) {
    const featureVector = [];

    featureVector.push(toFeaturizedNumber(lecture, 'watch'));
    featureVector.push(toFeaturizedNumber(lecture, 'degree'));
    featureVector.push(toFeaturizedNumber(lecture, 'interest'));
    featureVector.push(toFeaturizedNumber(lecture, 'voteAverage'));
    featureVector.push(toFeaturizedNumber(lecture, 'voteCount'));
    featureVector.push(toFeaturizedNumber(lecture, 'careerRelated'));
    featureVector.push(toFeaturizedNumber(lecture, 'relatedToSubject'));
    featureVector.push(toFeaturizedRelease(lecture));

    featureVector.push(toFeaturizedAdult(lecture));
    featureVector.push(toFeaturizedHomepage(lecture));
    featureVector.push(toFeaturizedLanguage(lecture));

    featureVector.push(...toFeaturizedFromDictionary(lecture, dictionaries.genresDictionary, 'genres'));
    featureVector.push(...toFeaturizedFromDictionary(lecture, dictionaries.overviewDictionary, 'overview'));
    featureVector.push(...toFeaturizedFromDictionary(lecture, dictionaries.studioDictionary, 'studio'));
    featureVector.push(...toFeaturizedFromDictionary(lecture, dictionaries.keywordsDictionary, 'keywords'));

    return featureVector;
  }
}

export function toFeaturizedRelease(lecture) {
  return lecture.release ? Number((lecture.release).slice(0, 4)) : 'undefined';
}

export function toFeaturizedAdult(lecture) {
  return lecture.adult === 'False' ? 0 : 1;
}

export function toFeaturizedHomepage(lecture) {
  return lecture.homepage ? 0 : 1;
}

export function toFeaturizedLanguage(lecture) {
  return lecture.language === 'en' ? 1 : 0;
}

export function toFeaturizedFromDictionary(lecture, dictionary, property) {
  // Fallback, because not all VideoLecture have associated keywords
  const propertyIds = (lecture[property] || []).map(value => value.id);
  const isIncluded = (value) => propertyIds.includes(value.id) ? 1 : 0;
  return dictionary.map(isIncluded);
}

export function toFeaturizedNumber(lecture, property) {
  const number = Number(lecture[property]);

  // Fallback for NaN
  if (number > 0 || number === 0) {
    return number;
  } else {
    return 'undefined';
  }
}

export function fromArrayToMap(array, property) {
  return array.map((value) => {
    const transformed = value[property].map((value) => ({
      id: value,
      name: value,
    }));

    return { ...value, [property]: transformed };
  });
}

export function withTokenizedAndStemmed(array, property) {
  return array.map((value) => ({
    ...value,
    [property]: value[property].tokenizeAndStem(),
  }));
}

export function filterByThreshold(dictionary, threshold) {
  return Object.keys(dictionary)
    .filter(key => dictionary[key].count > threshold)
    .map(key => dictionary[key]);
}

export function toDictionary(array, property) {
  const dictionary = {};

  array.forEach((value) => {
    // Fallback for null value after refactoring
    (value[property] || []).forEach((innerValue) => {
      if (!dictionary[innerValue.id]) {
        dictionary[innerValue.id] = {
          ...innerValue,
          count: 1,
        };
      } else {
        dictionary[innerValue.id] = {
          ...dictionary[innerValue.id],
          count: dictionary[innerValue.id].count + 1,
        }
      }
    });
  });

  return dictionary;
}

export function zip(VideoLecture, keywords) {
  return Object.keys(VideoLecture).map(mId => ({
    ...VideoLecture[mId],
    ...keywords[mId],
  }));
}

export default prepareVideoLecture;