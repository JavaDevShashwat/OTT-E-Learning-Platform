const mongoose = require("mongoose");
const User = require("../models/userModel");
const Video = require("../models/videoModel.js");
const Events = require("../models/upcomingEventsModel");
const Notes = require("../models/notesModel.js");
const Category = require("../models/categoryModel.js");
const Subject = require("../models/subjectModel.js");


exports.getAllVideo = async (req, res, next) => {
	try {
		const video = await Video.find({subject:req.params.subject});


        //The "video" inside rendor method is name of ejs File
		res.render("video", {
			video
		});
	} catch (error) {
		console.log(error);
	}
};

exports.getLoginPage = async (req, res , next)=>{
	res.render("login");
}

exports.getAdminPage = async (req, res , next)=>{
	const subject = await Subject.find({});
	res.render("admin" , {user : req.user , subject : subject});
}

exports.getStudentDashboard = async (req, res , next)=>{

	const latestNote = await Notes.find({}).sort({_id:-1}).limit(1);
	const latestVideo = await Video.find({}).sort({_id:-1}).limit(1);

	res.render('student_dashboard' , {user : req.user , latestNote : latestNote[0] , latestVideo : latestVideo[0]});
}

exports.getLecturesPage = async (req , res , next)=>{
	const subjects = await Subject.find({});
	const bgImages = [
		'/assets/physics.jpg',
		'/assets/chemistry.jpg',
		'/assets/biology.jpg'
	]
	res.render('lectures' , {subjects : subjects , bgImages})
}


exports.getSingleVideoPage = async (req , res , next)=>{
	const subject_index = req.params.index;
	const all_subjects = await Subject.find({});
	const subject = all_subjects[subject_index];
	const videosForSubject = await Video.find({subject : subject.name});
	const firstVideo = videosForSubject[req.query.videoIndex || 0];
	let index = req.query.videoIndex || 0;
	const videos = videosForSubject



	res.render('videos',{current_subject_index : subject_index , subject : subject , firstVideo : firstVideo , videos : videos , current_video_index:index});
}

exports.getEventsPage = async (req , res , next)=>{
	res.render('events');	
}

exports.getSingleNotesPage = async (req , res , next)=>{
	const subject_index = req.params.index;
	const all_subjects = await Subject.find({});
	const subject = all_subjects[subject_index];
	const notesForSubject = await Notes.find({subject : subject.name});

	res.render('noteList',{current_subject_index : subject_index , subject : subject , notes : notesForSubject });
}

exports.postLogin = async (req,res,next)=>{
	if(!req.user){
		next();
	}
	if(req.user.userRole === 'user'){
		res.redirect('/student')
	}
	else{
		res.redirect('/admin')
	}
	return;
}

exports.getNotesPage = async (req , res , next)=>{
	const subjects = await Subject.find({});
	const bgImages = [
		'/assets/physics.jpg',
		'/assets/chemistry.jpg',
		'/assets/biology.jpg'
	]
	res.render('notes' , {subjects : subjects , bgImages : bgImages})
}

exports.getLivePage = async (req , res , next)=>{
	res.render('live');
}

exports.getNotesPage