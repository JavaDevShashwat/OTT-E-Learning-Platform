// const { query } = require("express");
const express = require("express");
const mongoose = require("mongoose");
const Notes = require("../models/notesModel.js");
const multer = require("multer");
const Subject = require("../models/subjectModel.js");

const multerStorage = multer.diskStorage({
  destination:'public/notes',
  filename: (req, file, cb) => {
    const ext = file.mimetype.split('/')[1];
    cb(null, `notes-${Date.now()}.${ext}`)
  }
})
const upload = multer({
  storage: multerStorage,
});
exports.uploadNotes = upload.single("document")



exports.getAllNotes = async (req, res, next) => {
	try {
		const notes = await Notes.find({year:req.params.year,subject:req.params.subject});
		res.status(200).json({
			status: "success",
			result: notes.length,
			data: notes,
		});
	} catch (error) {
		console.log(error);
	}
};

exports.addNewNotes = async (req, res, next) => {
	try {
		const subject_selected = await Subject.find({});
		const final_subject_string = subject_selected[Number(req.body.subject)].name;
		const notes = await Notes.create({
			name : req.body.name , 
			subject : final_subject_string,
			year : req.body.year,
			document:req.file.filename
		});
		res.status(201).json({
			status: "success",
			data: {
				notes,
			},
		});
	} catch (error) {
		console.log(error);
	}
};

exports.getOneNotes = async (req, res, next) => {
	try {
		const notes = await Notes.findById(req.params.id);
		res.status(200).json({
			status: "success",
			data: {
				notes,
			},
		});
	} catch (error) {
		console.log(error);
	}
};

exports.getLatestNote = async (req , res , next)=>{
	try{
		const latestNote = await Notes.find({}).sort({_id:-1}).limit(1);
		res.status(200).json({
			status:"success",
			data:{
				latestNote
			}
		})
	}
	catch(error){
		console.log(error);
	}
}

// exports.updateCategory = async (req, res, next) => {
// 	try {
// 		const category = await Category.findByIdAndUpdate(req.params.id, req.body, {
// 			new: true,
// 			runValidators: true,
// 		});
// 		res.status(200).json({
// 			status: "success",
// 			data: {
// 				category,
// 			},
// 		});
// 	} catch (error) {
// 		console.log(error);
// 	}
// };

exports.deleteNotes = async (req, res, next) => {
	try {
		const notes = await Notes.findByIdAndDelete(req.params.id);
		res.status(204).json({
			status: "success",
			data: "null",
		});
	} catch (error) {
		console.log(error);
	}
};
