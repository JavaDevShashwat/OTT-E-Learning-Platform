// const { query } = require("express");
const express = require("express");
const mongoose = require("mongoose");
const Video = require("../models/videoModel.js");
const Subject = require("../models/subjectModel.js");
const multer = require("multer");

const multerStorage = multer.diskStorage({
  destination: 'public/videos',
  filename: (req, file, cb) => {
    const ext = file.mimetype.split('/')[1];
    cb(null, `video--${Date.now()}.${ext}`)
  }
})
const upload = multer({
  storage: multerStorage,
});
exports.uploadVideo = ()=>{
	upload.single("video")
}

exports.getAllVideo = async (req, res, next) => {
	try {
		const video = await Video.find({year:req.params.year,subject:req.params.subject});
		res.status(200).json({
			status: "success",
			result: video.length,
			data: video,
		});
	} catch (error) {
		console.log(error);
	}
};

exports.addNewVideo = async (req, res, next) => {
	try {
		const subject_selected = await Subject.find({});
		const final_subject_string = subject_selected[Number(req.body.subject)].name;
		const video = await Videos.create({
			name : req.body.name , 
			subject : final_subject_string,
			year : req.body.year,
			file:'video1.mp4'
		});
		res.status(201).json({
			status: "success",
			data: {
				video,
			},
		});
	} catch (error) {
		console.log(error);
	}
};

exports.getOneVideo = async (req, res, next) => {
	try {
		const video = await Video.findById(req.params.id);
		res.status(200).json({
			status: "success",
			data: {
				video,
			},
		});
	} catch (error) {
		console.log(error);
	}
};




exports.deleteVideo = async (req, res, next) => {
	try {
		const video = await Video.findByIdAndDelete(req.params.id);
		res.status(204).json({
			status: "success",
			data: "null",
		});
	} catch (error) {
		console.log(error);
	}
};

exports.prepareVideos=async(req,res,next)=>{
	try {
		const video = await Video.find();
		res.status(204).json({
			status: "success",
			data: "null",
		});
	} catch (error) {
		console.log(error);
	}
};