const mongoose = require("mongoose");

const NotesSchema = new mongoose.Schema({
	name: {
		type: String,
		required: true,
	},
    subject:{
        type:String
    },
    year:{
        type:String
    },
	document:{
		type:String
	},
	createdAt: {
		type: Date,
		default:new Date()
	},
});

const Notes = mongoose.model("Notes", NotesSchema);

module.exports = Notes;
