const mongoose = require("mongoose");

const VideoSchema = new mongoose.Schema({
	name: {
		type: String,
		required: true,
	},
    subject:{
        type:String
    },
    year:{
        type:String
    },
	file:{
		type:String
	},
	createdAt: {
		type: Date,
		default:new Date()
	},
});

const Video = mongoose.model("Video", VideoSchema);

module.exports = Video;
