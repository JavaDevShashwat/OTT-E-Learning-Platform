const mongoose = require("mongoose");

const CategorySchema = new mongoose.Schema({
	name: {
		type: String,
		required: true,
		unique: [true, "This Heading/Category Already Exist"],
	},
	photo:{
		type:String
	},
	createdAt: {
		type: Date,
		default:new Date()
	},
});

const Category = mongoose.model("Category", CategorySchema);

module.exports = Category;
