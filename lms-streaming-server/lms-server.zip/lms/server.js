const mongoose = require("mongoose");
const dotenv = require("dotenv");
const app = require("./app");
const cors = require("cors");
dotenv.config({ path: "./config.env" });
const http = require("http");
const socketio = require("socket.io");
const server = http.createServer(app);

app.use(cors());
const DB = process.env.DATABASE_DEV.replace(
  "<PASSWORD>",
  process.env.DATABASE_DEV_PASSWORD
);

mongoose
  .connect(DB, {
    useNewUrlParser: true,
    useCreateIndex: true,
    useFindAndModify: true,
    useUnifiedTopology: true,
    useFindAndModify: false,
  })
  .then(() => {
    console.log("DB Connection Successfull");
  });

console.log(process.env.NODE_ENV);

const PORT = 3500;

server.listen(process.env.PORT || PORT, () =>
  console.log(`Server has started.`)
);
