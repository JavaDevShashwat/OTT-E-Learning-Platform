let loginForm = new FormObject('#login-btn',[
	new EmailInputElement('#login-email','#login-email+i','email',0),
	new PasswordInputElement('#login-password','#login-password+i','password',0)
],'/api/v1/user/login')
.init()
.addOption('redirectOnSuccess','/')
.addOption('customSuccessMessage','Logged In Successfully !!!');

