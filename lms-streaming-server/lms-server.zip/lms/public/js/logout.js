let logout_button = new MyElement('#logout-btn');
BindRequestThenRedirect('/login','/api/v1/user/logout',logout_button)
