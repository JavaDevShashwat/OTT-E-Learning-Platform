let upload_notes_form = new FormObject('#upload-notes-btn',[
    new NonEmptyElement('#note-title','#note-title+i','name',0),
    new RadioButton('#note-subject-options','#note-subject-options+i','subject',0),
    new RadioButton('#note-year-options','#note-year-options+i','year',0),
    new FileInputElement('#note-file','#open-note-file','#open-note-label','#note-file-wrapper+i','document',0 , ['application/pdf']),
],'/api/v1/notes'
).init();

let upload_videos_form = new FormObject('#upload-video-btn',[
    new NonEmptyElement('#video-title','#video-title+i','name',0),
    new RadioButton('#video-subject-options','#video-subject-options+i','subject',0),
    new RadioButton('#video-year-options','#video-year-options+i','year',0),
    new FileInputElement('#video-file','#open-video-file','#open-video-label','#video-file-wrapper+i','file',0 , ['video/mp4']),
],'/api/v1/videos')
.init();

let password = new PasswordInputElement('#user-password','#user-password+i','password',0);
let create_new_user_form = new FormObject('#create-new-user',[
    new RadioButton('#user-type-options', '#user-type-options+i','userRole',0),
    new NonEmptyElement('#user-name','#user-name+i','name',0),
    new EmailInputElement('#user-email','#user-email+i','email',0),
    password,
    new ConfirmPasswordElement('#user-confirm-password','#user-confirm-password+i',password,'',0)
],'/api/v1/user/signup').init();


let create_new_subject_form = new FormObject('#create-new-subject',[
    new NonEmptyElement('#subject-title' , '#subject-title+i','name',0)
],'/api/v1/subject').init(); 

let modal_wrapper = new MyElement('div.modal-wrapper').init(false);
let note_modal = new MyElement('#note-modal').init(false);
let user_modal = new MyElement('#user-modal').init(false);
let subject_modal = new MyElement('#subject-modal').init(false);
let video_modal = new MyElement('#video-modal').init(false);


function openModal(index){

    modal_wrapper.toDefault();
    switch(index){
        case 0 : 
        note_modal.toDefault();
        break;
        case 1 : 
        video_modal.toDefault();
        break;
        case 2 : 
        user_modal.toDefault();
        break;
        case 3 : 
        subject_modal.toDefault();
        break;
        default : break;
    }

}
function closeModal(index){

    modal_wrapper.hide();
    switch(index){
        case 0 : 
        note_modal.hide();
        break;
        case 1 : 
        video_modal.hide();
        break;
        case 2 : 
        user_modal.hide();
        break;
        case 3 : 
        subject_modal.hide();
        break;
        default : break;
    }

}