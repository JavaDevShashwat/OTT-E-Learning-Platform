const express = require("express");
const notesController = require("../controllers/notesController");
const router = express.Router();

router
  .route("/")
  .get(notesController.getAllNotes)
  .post(notesController.uploadNotes,notesController.addNewNotes);
router
  .get('/delete/:id',notesController.deleteNotes)
router
  .get('/latestNote',notesController.getLatestNote)
router
  .route("/:id")
  .get(notesController.getOneNotes)
  .delete(notesController.deleteNotes);

module.exports = router;
