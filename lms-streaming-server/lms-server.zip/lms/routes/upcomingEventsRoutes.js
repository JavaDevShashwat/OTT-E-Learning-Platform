const express = require("express");
const upcomingEventsController = require("../controllers/upcomingEventsController");

const router = express.Router();

router
  .route("/")
  .get(upcomingEventsController.getAllEvents)
  .post(upcomingEventsController.uploadUpcomingEventsImage,upcomingEventsController.addNewEvent);

router
  .route("/:id")
  .get(upcomingEventsController.getOneEvent)
  .patch(upcomingEventsController.uploadUpcomingEventsImage,upcomingEventsController.updateEvent)
  .delete(upcomingEventsController.deleteEvent);

module.exports = router;
