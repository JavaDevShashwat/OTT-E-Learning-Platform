const express = require("express");
const videoController = require("../controllers/videoController");
const router = express.Router();

router
  .route("/")
  .get(videoController.getAllVideo)
  .post(videoController.uploadVideo,videoController.addNewVideo);
  // .post(videoController.addNewVideo);
router
  .get('/delete/:id',videoController.deleteVideo)
router
  .get('/recomendation',videoController.prepareVideos)
router
  .route("/:id")
  .get(videoController.getOneVideo)
  .delete(videoController.deleteVideo);

module.exports = router;
