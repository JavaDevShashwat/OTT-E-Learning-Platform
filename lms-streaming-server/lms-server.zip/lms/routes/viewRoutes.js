var express = require("express");
const viewController = require("./../controllers/viewController");
const authController = require("./../controllers/authController");

var router = express.Router();


router.get("/", authController.protect , viewController.postLogin , (req , res , next)=>{
    res.redirect('/login');
});
router.get("/login", authController.protect , viewController.postLogin , (req , res , next)=>{
    res.render('login');
});

router.use(authController.isLoggedIn);
router.get("/admin" , authController.protect , authController.restrictTo('admin' , 'teacher') ,  viewController.getAdminPage);
router.get('/student' , authController.protect , authController.restrictTo('user') ,viewController.getStudentDashboard);
router.get('/lectures',authController.protect , authController.restrictTo('user'),viewController.getLecturesPage)
router.get('/notes',authController.protect , authController.restrictTo('user'),viewController.getNotesPage)
router.get('/singleSubjectVideos/:index',authController.protect , authController.restrictTo('user'),viewController.getSingleVideoPage)
router.get('/singleSubjectNotes/:index',authController.protect , authController.restrictTo('user'),viewController.getSingleNotesPage)
router.get("/live",authController.protect , authController.restrictTo('user'),viewController.getLivePage);
router.get("/events",authController.protect , authController.restrictTo('user'),viewController.getEventsPage);

module.exports = router;

